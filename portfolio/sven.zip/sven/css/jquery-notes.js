
Jquery
	write less and do more with javascript. It makes it easier to program

Use version 2.X version
JQuery is not supported by IE 6, 7, 8

Jquery ccan be loaded from CDN or file

first load library after it load the code

when working on a website:
know what is included and what it does


callBack function:
	
